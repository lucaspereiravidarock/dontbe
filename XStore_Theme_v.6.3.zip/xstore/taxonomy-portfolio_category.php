<?php

defined( 'ABSPATH' ) || exit( 'Direct script access denied.' );

get_template_part('portfolio');