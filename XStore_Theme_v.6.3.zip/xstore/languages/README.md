# Notice! Do not place your custom translation files here.

XStore will look in this directory for translations as a fallback. It is however recommended that you use the global WordPress language directory and install your translations like so: `/wp-content/languages/themes/xstore-es_ES.mo`. That way they will not be lost or overwritten during XStore updates.

You can read more about installing XStore in your language [here](http://xstore.helpscoutdocs.com/category/18-theme-translation).