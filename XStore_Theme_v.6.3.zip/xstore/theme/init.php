<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

require_once( apply_filters('etheme_file_url', ETHEME_THEME . 'functions.php') );
require_once( apply_filters('etheme_file_url', ETHEME_THEME . 'custom-styles.php') );