<?php if ( ! defined( 'ABSPATH' ) ) exit( 'No direct script access allowed' );
/**
 * Template "Footer" for 8theme dashboard.
 *
 * @since   6.0.2
 * @version 1.0.0
 */
?>
	<div class="etheme-page-footer">
	</div>
</div>