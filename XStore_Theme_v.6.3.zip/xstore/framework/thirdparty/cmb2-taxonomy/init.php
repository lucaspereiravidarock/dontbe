<?php

require_once dirname(__FILE__) . '/includes/CMB2_Taxonomy.php';

new CMB2_Taxonomy();