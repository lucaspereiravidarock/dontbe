<?php 
/**
 * The template for single product description
 *
 * @since   2.2.1
 * @version 1.0.0
 * last changes in 2.2.1
 */
	
global $post;

the_content();