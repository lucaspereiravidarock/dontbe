<?php
/**
 * Menu list item shortcode.
 *
 * @since      1.4.4
 * @package    ETC
 * @subpackage ETC/Controllers/vc/class
 */
if ( class_exists( 'WPBakeryShortCode' ) ) {
	class WPBakeryShortCode_ET_Menu_List_Item extends \WPBakeryShortCode {
	}
}
